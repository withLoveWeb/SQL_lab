BEGIN;

CREATE TABLE IF NOT EXISTS "C22-702-24".clubs (
     club_id serial, 
     short_club_name character varying NOT NULL,
      long_club_name character varying NOT NULL, 
      PRIMARY KEY (club_id), 
      UNIQUE (short_club_name, long_club_name) 
);

CREATE TABLE IF NOT EXISTS "C22-702-24".countries ( 
    country_id serial, 
    short_country_name character varying NOT NULL, 
    long_country_name character varying NOT NULL, 
    region_name character varying NOT NULL check(region_name='Asia' OR region_name='Europe' OR region_name='Africa' OR region_name='Australia and Oceania' OR region_name='North America' OR region_name='South and Latin America'), 
    PRIMARY KEY (country_id), 
    UNIQUE (short_country_name, long_country_name) 
);

CREATE TABLE IF NOT EXISTS "C22-702-24".teams ( 
    team_id serial, 
    team_name character varying NOT NULL, 
    club_id integer , 
    country_id integer , 
    total_score integer, 
    total_matches integer, 
    total_wins integer, 
    total_losses integer, 
    total_draws integer, 
    PRIMARY KEY (team_id), 
    UNIQUE (team_name,club_id),
    CONSTRAINT check_team CHECK( (club_id IS NOT NULL AND country_id IS NULL) OR ( country_id IS NOT NULL AND club_id IS NULL )) 
);

CREATE TABLE IF NOT EXISTS "C22-702-24".players ( 
    player_id serial, 
    name character varying NOT NULL, 
    last_name character varying NOT NULL, 
    second_name character varying, 
    birthday date, 
    country_id integer NOT NULL, 
    PRIMARY KEY (player_id) 
);

CREATE TABLE IF NOT EXISTS "C22-702-24".schedule ( 
    match_id serial, 
    first_team integer NOT NULL, 
    second_team integer NOT NULL, 
    date_of_match date NOT NULL, 
    first_goals integer, 
    first_after_match_penalty integer, 
    second_goals integer, 
    second_after_match_penalty integer, 
    first_score integer, 
    second_score integer, 
    type_of_match character varying NOT NULL CHECK(type_of_match='group stage' OR type_of_match='1/8' OR type_of_match='1/4' OR type_of_match='1/2' OR type_of_match='match for third place' OR type_of_match='final'), 
    PRIMARY KEY (match_id), 
    UNIQUE (first_team, second_team, date_of_match) 
);

CREATE TABLE IF NOT EXISTS "C22-702-24".players_on_field ( 
    id serial, 
    match_id integer NOT NULL, 
    team_id integer NOT NULL, 
    player_id integer NOT NULL, 
    PRIMARY KEY (id) ,
    UNIQUE (match_id, team_id, player_id) 
);

CREATE TABLE IF NOT EXISTS "C22-702-24".goals ( 
    goal_id serial, 
    player_on_field_id integer NOT NULL, 
    minutes integer NOT NULL, 
    seconds integer NOT NULL, 
    PRIMARY KEY (goal_id),
    UNIQUE (player_on_field_id, minutes, seconds) 
);

CREATE TABLE IF NOT EXISTS "C22-702-24".violations ( 
    violation_id serial, 
    player_on_field_id integer NOT NULL, 
    minutes integer NOT NULL, 
    seconds integer NOT NULL, 
    type_of_violation character varying check(type_of_violation='Foul' OR type_of_violation='Yellow Card' OR type_of_violation='Red Card' OR type_of_violation='Offside' OR type_of_violation='Handball' OR type_of_violation='Diving'),  
    PRIMARY KEY (violation_id) ,
    UNIQUE(player_on_field_id,minutes,seconds,type_of_violation)
);

ALTER TABLE IF EXISTS "C22-702-24".teams 
    ADD FOREIGN KEY (club_id) 
    REFERENCES "C22-702-24".clubs (club_id) MATCH SIMPLE 
    ON UPDATE NO ACTION 
    ON DELETE NO ACTION 
    NOT VALID;

ALTER TABLE IF EXISTS "C22-702-24".teams 
    ADD FOREIGN KEY (country_id) 
    REFERENCES "C22-702-24".countries (country_id) MATCH SIMPLE 
    ON UPDATE NO ACTION 
    ON DELETE NO ACTION 
    NOT VALID;

ALTER TABLE IF EXISTS "C22-702-24".players 
    ADD FOREIGN KEY (country_id) 
    REFERENCES "C22-702-24".countries (country_id) MATCH SIMPLE 
    ON UPDATE NO ACTION 
    ON DELETE NO ACTION 
    NOT VALID;

ALTER TABLE IF EXISTS "C22-702-24".schedule 
    ADD FOREIGN KEY (first_team) 
    REFERENCES "C22-702-24".teams (team_id) MATCH SIMPLE 
    ON UPDATE NO ACTION 
    ON DELETE NO ACTION 
    NOT VALID;

ALTER TABLE IF EXISTS "C22-702-24".schedule 
    ADD FOREIGN KEY (second_team) 
    REFERENCES "C22-702-24".teams (team_id) MATCH SIMPLE 
    ON UPDATE NO ACTION 
    ON DELETE NO ACTION 
    NOT VALID;

ALTER TABLE IF EXISTS "C22-702-24".players_on_field 
    ADD FOREIGN KEY (match_id) 
    REFERENCES "C22-702-24".schedule (match_id) MATCH SIMPLE 
    ON UPDATE NO ACTION 
    ON DELETE NO ACTION 
    NOT VALID;

ALTER TABLE IF EXISTS "C22-702-24".players_on_field 
    ADD FOREIGN KEY (team_id) 
    REFERENCES "C22-702-24".teams (team_id) MATCH SIMPLE 
    ON UPDATE NO ACTION 
    ON DELETE NO ACTION 
    NOT VALID;

ALTER TABLE IF EXISTS "C22-702-24".players_on_field 
    ADD FOREIGN KEY (player_id) 
    REFERENCES "C22-702-24".players (player_id) MATCH SIMPLE 
    ON UPDATE NO ACTION 
    ON DELETE NO ACTION 
    NOT VALID;

ALTER TABLE IF EXISTS "C22-702-24".goals 
    ADD FOREIGN KEY (player_on_field_id) 
    REFERENCES "C22-702-24".players_on_field (id) MATCH SIMPLE 
    ON UPDATE NO ACTION 
    ON DELETE NO ACTION 
    NOT VALID;

ALTER TABLE IF EXISTS "C22-702-24".violations 
    ADD FOREIGN KEY (player_on_field_id) 
    REFERENCES "C22-702-24".players_on_field (id) MATCH SIMPLE 
    ON UPDATE NO ACTION 
    ON DELETE NO ACTION 
    NOT VALID;

END;