-- variant 2
-- task 1
CREATE TABLE staff(
	id bigint PRIMARY KEY,
	last_name varchar(64) not null,
	first_name varchar(64) not null,
	second_name varchar(64),
	sex char(1) not null check(sex in ('м','ж')),
	birthday date not null,
	post varchar(128) not null , 
	department varchar(128) not null,
	unique(post, department),
	head_id bigint,
	FOREIGN KEY (head_id) REFERENCES staff(id)
);

-- task 2
CREATE SEQUENCE staff_id_seq increment BY 1 START WITH 1;

insert into staff(id, last_name, first_name, second_name, sex, birthday, post, department, head_id)
values(nextval('staff_id_seq'), 'Сталин', 'Иосиф', 'Виссарионович', 'м', '1879.12.21','Председатель', 'ГКО', NULL);
insert into staff(id, last_name, first_name, second_name, sex, birthday, post, department, head_id)
values(nextval('staff_id_seq'), 'Молотов', 'Вячеслав', 'Михайлович', 'м', '1890.03.09','Заместитель председателя', 'ГКО', (SELECT id FROM staff WHERE last_name = 'Сталин'));
insert into staff(id, last_name, first_name, second_name, sex, birthday, post, department, head_id)
values(nextval('staff_id_seq'), 'Маленков', 'Георгий', 'Максимилианович', 'м', '1902.01.08','Начальник', 'УК ЦК ВКП(б)', (SELECT id FROM staff WHERE last_name = 'Молотов'));
insert into staff(id, last_name, first_name, second_name, sex, birthday, post, department, head_id)
values(nextval('staff_id_seq'), 'Ворошилов', 'Климент', 'Ефремович', 'м', '1881.02.04','Председатель КО', 'СНК', (SELECT id FROM staff WHERE last_name = 'Молотов'));
insert into staff(id, last_name, first_name, second_name, sex, birthday, post, department, head_id)
values(nextval('staff_id_seq'), 'Микоян', 'Анастас', 'Иванович', 'м', '1895.11.25','Председатель', 'КП-ВС РККА', (SELECT id FROM staff WHERE last_name = 'Молотов'));

SELECT * FROM staff;

-- task 3

SELECT s.last_name , s.first_name , s.second_name , s.post ,
h.last_name ,  h.first_name , h.second_name , h.post  
FROM staff s LEFT JOIN staff h on s.id = h.head_id;

-- task 4

BEGIN;
WITH tmp as(
	SELECT id FROM staff s1 WHERE 
	(SELECT COUNT(*) FROM staff s2 WHERE s2.head_id = s1.id) = 0
)

UPDATE staff SET head_id = (SELECT id FROM staff WHERE last_name = 'Сталин')
WHERE id IN (SELECT * FROM tmp);

SELECT * FROM staff;
ROLLBACK;
-- task 5 


CREATE OR REPLACE PROCEDURE birthday_boys(month_ integer) AS
$$
	DECLARE 
		query_r CURSOR FOR SELECT * FROM staff WHERE EXTRACT(month FROM birthday)=month_;
		row_e staff%ROWTYPE;
		people_count int;
		max_people_age int;
		min_people_age int;
		avg_people_age float;
	BEGIN

		FOR row_e IN query_r LOOP
			RAISE NOTICE 'people who have birthday in this month: % % %', row_e.last_name, row_e.first_name, row_e.second_name;
		END LOOP;

		SELECT COUNT(*),  MAX(EXTRACT(year FROM current_date) - EXTRACT(year FROM birthday)), 
				 MIN(EXTRACT(year FROM current_date) - EXTRACT(year FROM birthday)), 
				 AVG(EXTRACT(year FROM current_date) - EXTRACT(year FROM birthday)) 
		INTO people_count, max_people_age, min_people_age, avg_people_age 
		FROM staff WHERE EXTRACT(month FROM birthday) = month_;
			
			
		raise notice 'Total COUNT: %', people_count;
		RAISE NOTICE 'Maximum age: %', max_people_age;
    	RAISE NOTICE 'Minimum age: %', min_people_age;
    	RAISE NOTICE 'Average age: %', avg_people_age;
		
	END;
$$ LANGUAGE plpgsql;

call birthday_boys(11);

-- task 6

WITH RECURSIVE tmp AS (
	SELECT last_name , id, head_id, 1 AS num FROM staff
	UNION all
	SELECT s.last_name , s.id, s.head_id, t.num + 1 FROM staff s
	JOIN tmp t on p.id = s.head_id
)
SELECT MAX(num) FROM tmp;


