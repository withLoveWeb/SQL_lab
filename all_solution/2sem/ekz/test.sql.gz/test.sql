-- Create the table
CREATE TABLE people (
    id SERIAL PRIMARY KEY,
    last_name TEXT,
    first_name TEXT,
    second_name TEXT,
    parent_id INTEGER,
    child_id INTEGER
);

-- Insert data into the table
INSERT INTO people (last_name, first_name, second_name, parent_id,child_id) VALUES
('Ivanov', 'Ivan', 'Ivanovich', null,2),
('Petrov', 'Petr', 'Petrovich', 1,3),
('Sidorov', 'Sidor', 'Sidorovich', 2,null),
('Vasilev', 'Petr', 'Vasilevich', null,5),
('Mihailov', 'Mihail', 'Ivanovich', 4,null);

-- Select all records from the table
SELECT * FROM people;


SELECT t3.id, t3.first_name FROM people t3 LEFT OUTER JOIN people t1 ON(t3.parent_id=t1.id)  ORDER BY trim(t3.first_name) ASC LIMIT 1;
LEFT OUTER JOIN people t2 ON(t1.id=t2.parent_id) ORDER BY trim(t3.first_name) ASC LIMIT 1;



SELECT t3.first_name, t2.parent_id, t1.first_name FROM people t3 FULL OUTER JOIN people t1 ON(t3.id = t1.parent_id) 
INNER JOIN people t2 ON(t1.child_id = t2.id) ORDER BY t1.first_name ASC LIMIT 1;

SELECT * FROM people t3 FULL OUTER JOIN people t1 ON(t3.id = t1.parent_id) 
INNER JOIN people t2 ON(t1.child_id = t2.id);


SELECT * FROM people t3 FULL OUTER JOIN people t1 ON(t3.id = t1.parent_id) ;