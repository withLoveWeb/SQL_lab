--variant 1 

-- задание 1
DROP TABLE IF EXISTS people;
create table people(
	id int primary key,
	last_name varchar(32) not null, 
	first_name varchar(32) not null,
	second_name varchar(32) not null,
	sex char(1) check(sex IN ('м', 'ж')),
	birthday date,
	death_date date,
	mother_id int,
	father_id int,
	FOREIGN KEY (mother_id) REFERENCES people(id),
    FOREIGN KEY (father_id) REFERENCES people(id)
);

-- задание 2
DROP SEQUENCE IF EXISTS people_id_seq;
create sequence people_id_seq increment by -1 start with -1;
insert into people(id, last_name, first_name, second_name, sex, birthday, death_date, mother_id, father_id)
values (nextval('people_id_seq'), 'Романов', 'Николай', 'Павлович', 'м', '1796-07-17', '1855-03-14', null, null),
(nextval('people_id_seq'), 'Романова', 'Александра', 'Федоровна', 'ж', '1798-07-13', '1860-01-11', null, null),
(nextval('people_id_seq'), 'Романов', 'Александр', 'Николаевич', 'м', '1818-04-29', '1881-03-13', currval('people_id_seq')+1, currval('people_id_seq')+2),
(nextval('people_id_seq'), 'Романова', 'Мария', 'Александровна', 'ж', '1824-08-08', '1880-06-03', null, null),
(nextval('people_id_seq'), 'Романов', 'Александр', 'Александрович', 'м', '1845-03-10', '1894-11-01', currval('people_id_seq')+1, currval('people_id_seq')+2),
(nextval('people_id_seq'), 'Романов', 'Дядя', 'Николаевич', 'м', '1845-03-10', '1894-11-01', null, currval('people_id_seq')+3);

-- task 3

SELECT p.last_name , p.first_name , p.second_name ,
       s.last_name , s.first_name , s.second_name 
FROM people p LEFT JOIN people s ON p.id = s.father_id
WHERE p.sex = 'м';

-- task 4

UPDATE people SET birthday = birthday + interval '3 months' , death_date = death_date + interval '3 months';

--task 5

CREATE OR REPLACE PROCEDURE long_livers(age INTEGER) AS $$
DECLARE
    total_count INTEGER;
    max_age INTEGER;
    min_age INTEGER;
    avg_age NUMERIC;
BEGIN
    SELECT COUNT(*), MAX(EXTRACT(YEAR FROM death_date) - EXTRACT(YEAR FROM birthday)), MIN(EXTRACT(YEAR FROM death_date) - EXTRACT(YEAR FROM birthday)), AVG(EXTRACT(YEAR FROM death_date) - EXTRACT(YEAR FROM birthday))
    INTO total_count, max_age, min_age, avg_age
    FROM people
    WHERE EXTRACT(YEAR FROM death_date) - EXTRACT(YEAR FROM birthday) > age;

    RAISE NOTICE 'Total count of people living longer than 0 years: %', total_count;
    RAISE NOTICE 'Maximum age: %', max_age;
    RAISE NOTICE 'Minimum age: %', min_age;
    RAISE NOTICE 'Average age: %', avg_age;
END;
$$ LANGUAGE plpgsql;
SELECT long_livers(0);

--task 6

WITH RECURSIVE family_tree AS (
    SELECT id, father_id, 1 AS generation
    FROM people pe
    WHERE father_id IS NULL
    UNION ALL
    SELECT pe.id, pe.father_id, ft.generation + 1
    FROM people pe
    JOIN family_tree ft ON pe.father_id = ft.id
)
SELECT * FROM family_tree;

SELECT MAX(generation) AS max_generation
FROM family_tree;

