    --INSERTS
INSERT INTO "C22-702-24".clubs (short_club_name, long_club_name) VALUES ('AN', 'Arsenal');
INSERT INTO "C22-702-24".clubs (short_club_name, long_club_name) VALUES ('LP', 'Liverpool');
INSERT INTO "C22-702-24".clubs (short_club_name, long_club_name) VALUES ('MC', 'Manchester City');
INSERT INTO "C22-702-24".clubs (short_club_name, long_club_name) VALUES ('AV', 'Aston Villa');
INSERT INTO "C22-702-24".clubs (short_club_name, long_club_name) VALUES ('TH', 'Tottenham');
INSERT INTO "C22-702-24".clubs (short_club_name, long_club_name) VALUES ('MU', 'Manchester United');

INSERT INTO "C22-702-24".countries (short_country_name, long_country_name, region_name) VALUES ('UK', 'United Kingdom', 'Europe');
INSERT INTO "C22-702-24".countries (short_country_name, long_country_name, region_name) VALUES ('DE', 'Germany', 'Europe');
INSERT INTO "C22-702-24".countries (short_country_name, long_country_name, region_name) VALUES ('GE', 'Georgia', 'Asia');
INSERT INTO "C22-702-24".countries (short_country_name, long_country_name, region_name) VALUES ('CG', 'Congo', 'Africa');
INSERT INTO "C22-702-24".countries (short_country_name, long_country_name, region_name) VALUES ('PL', 'Poland', 'Europe');
INSERT INTO "C22-702-24".countries (short_country_name, long_country_name, region_name) VALUES ('TG', 'Togo', 'Africa');
INSERT INTO "C22-702-24".countries (short_country_name, long_country_name, region_name) VALUES ('RUS', 'Russia', 'Asia');

                                                                                                                                                                                     
INSERT INTO "C22-702-24".teams (team_name, club_id, country_id, total_score, total_matches, total_wins, total_losses, total_draws) VALUES ('Arsenal',1,NULL,            10,4, 3,0,1);
INSERT INTO "C22-702-24".teams (team_name, club_id, country_id, total_score, total_matches, total_wins, total_losses, total_draws) VALUES ('Liverpool',2,NULL,           6,3, 2,1,0);
INSERT INTO "C22-702-24".teams (team_name, club_id, country_id, total_score, total_matches, total_wins, total_losses, total_draws) VALUES ('Manchester City Main',3,NULL,6,3, 2,1,0); 
INSERT INTO "C22-702-24".teams (team_name, club_id, country_id, total_score, total_matches, total_wins, total_losses, total_draws) VALUES ('Aston Villa Junior',4,NULL,  7,4, 2,1,1); 
INSERT INTO "C22-702-24".teams (team_name, club_id, country_id, total_score, total_matches, total_wins, total_losses, total_draws) VALUES ('Tottenham',5,NULL,           0,3, 0,3,0);  
INSERT INTO "C22-702-24".teams (team_name, club_id, country_id, total_score, total_matches, total_wins, total_losses, total_draws) VALUES ('MU Junior',6,NULL,           0,3, 0,3,0); 

-- W L D
-- 3 0 0
-- 2 1 0
-- 2 1 0
-- 2 1 0
-- 0 3 0
-- 0 3 0

INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('Alexander', 'Smith', 'Johnson', '1990-01-01', 1);
INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('Benjamin', 'Williams', 'Brown', '1991-02-02', 2);
INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('Christopher', 'Jones', 'Davis', '1992-03-03', 3);
INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('Daniel', 'Martinez', 'Wilson', '1993-04-04', 4);
INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('Edward', 'Taylor', 'Anderson', '1994-05-05', 5);
INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('Felix', 'Brown', 'Thompson', '1995-06-06', 6);
INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('George', 'Wilson', 'Clark', '1996-07-07', 1);
INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('Henry', 'Johnson', 'Lewis', '1997-08-08', 2);
INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('Isaac', 'Davis', 'Harris', '1998-09-09', 3);
INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('James', 'Martinez', 'Miller', '1999-10-10', 4);
INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('John', 'Doe', 'Smith', '1995-05-05', 1);
INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('Bob', 'Johnson', 'Brown', '1996-06-06', 2);
INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('Michael', 'Williams', 'Jones', '1997-07-07', 3);
INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('Smith', 'Davis', 'Wilson', '1998-08-08', 4);
INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('William', 'Miller', 'Taylor', '1999-09-09', 5);
INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('Oliver', 'Anderson', 'Martinez', '2000-10-10', 6);
INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('Kevin', 'Brown', 'Adams', '2000-11-11', 5);
INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('Liam', 'Martinez', 'Baker', '2001-12-12', 6);
INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('Mason', 'Johnson', 'Cooper', '2002-01-13', 1);
INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('Nathan', 'Davis', 'Evans', '2003-02-14', 2);
INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('Owen', 'Smith', 'Fisher', '2004-03-15', 3);

-- INSERT INTO "C22-702-24".players (name, last_name, second_name, birthday, country_id) VALUES ('Hoh', 'Ol', 'Fisher', '2002-03-15', 13);



INSERT INTO "C22-702-24".schedule 
(first_team, second_team, date_of_match, first_goals, first_after_match_penalty, second_goals, second_after_match_penalty, first_score, second_score, type_of_match) 
VALUES (1, 2, '2024-03-30', 2, null, 1, null, 3, 0, 'group stage');

INSERT INTO "C22-702-24".schedule 
(first_team, second_team, date_of_match, first_goals, first_after_match_penalty, second_goals, second_after_match_penalty, first_score, second_score, type_of_match) 
VALUES (3, 5, '2024-03-30', 3, null, 0, null, 3, 0, 'group stage');

INSERT INTO "C22-702-24".schedule 
(first_team, second_team, date_of_match, first_goals, first_after_match_penalty, second_goals, second_after_match_penalty, first_score, second_score, type_of_match) 
VALUES (4, 6, '2024-03-30', 1, null, 0, null, 3, 0, 'group stage');


INSERT INTO "C22-702-24".schedule 
(first_team, second_team, date_of_match, first_goals, first_after_match_penalty, second_goals, second_after_match_penalty, first_score, second_score, type_of_match) 
VALUES (1, 6, '2024-04-07', 5, null, 1, null, 3, 0, 'group stage');

INSERT INTO "C22-702-24".schedule 
(first_team, second_team, date_of_match, first_goals, first_after_match_penalty, second_goals, second_after_match_penalty, first_score, second_score, type_of_match) 
VALUES (2, 5, '2024-04-08', 2, null, 1, null, 3, 0, 'group stage');

INSERT INTO "C22-702-24".schedule 
(first_team, second_team, date_of_match, first_goals, first_after_match_penalty, second_goals, second_after_match_penalty, first_score, second_score, type_of_match) 
VALUES (3, 4, '2024-04-08', 0, null, 2, null, 0, 3, 'group stage');


INSERT INTO "C22-702-24".schedule 
(first_team, second_team, date_of_match, first_goals, first_after_match_penalty, second_goals, second_after_match_penalty, first_score, second_score, type_of_match) 
VALUES (2, 4, '2024-04-14', 3, null, 1, null, 3, 0, 'group stage');

INSERT INTO "C22-702-24".schedule 
(first_team, second_team, date_of_match, first_goals, first_after_match_penalty, second_goals, second_after_match_penalty, first_score, second_score, type_of_match) 
VALUES (3, 6, '2024-04-14', 1, null, 0, null, 3, 0, 'group stage');

INSERT INTO "C22-702-24".schedule 
(first_team, second_team, date_of_match, first_goals, first_after_match_penalty, second_goals, second_after_match_penalty, first_score, second_score, type_of_match) 
VALUES (1, 5, '2024-04-15', 2, null, 1, null, 3, 0, 'group stage');


INSERT INTO "C22-702-24".schedule 
(first_team, second_team, date_of_match, first_goals, first_after_match_penalty, second_goals, second_after_match_penalty, first_score, second_score, type_of_match) 
VALUES (1, 4, '2024-04-21', 2, null, 2, null, 1, 1, 'group stage');

INSERT INTO "C22-702-24".schedule 
(first_team, second_team, date_of_match, first_goals, first_after_match_penalty, second_goals, second_after_match_penalty, first_score, second_score, type_of_match) 
VALUES (2, 3, '2024-04-22', null, null, null, null, null, null, 'group stage');

INSERT INTO "C22-702-24".schedule 
(first_team, second_team, date_of_match, first_goals, first_after_match_penalty, second_goals, second_after_match_penalty, first_score, second_score, type_of_match) 
VALUES (5, 6, '2024-04-22', null, null, null, null, null, null, 'group stage');


-- WITH tmp AS(
-- 	SELECT first_team , COUNT(*) AS c FROM "C22-702-24".schedule WHERE first_score=3 GROUP BY first_team
-- 	UNION ALL
-- 	SELECT second_team , COUNT(*) AS c FROM "C22-702-24".schedule WHERE second_score=3 GROUP BY second_team
-- )
-- SELECT first_team , SUM(c) FROM tmp GROUP BY first_team;

INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (1, 1, 1);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (1, 1, 2);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (1, 1, 3);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (1, 2, 4);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (1, 2, 5);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (1, 2, 6);

INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (2, 3, 7);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (2, 3, 8);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (2, 3, 9);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (2, 5, 13);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (2, 5, 14);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (2, 5, 15);

INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (3, 4, 10);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (3, 4, 11);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (3, 4, 12);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (3, 6, 16);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (3, 6, 17);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (3, 6, 18);



INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (4, 1, 1);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (4, 1, 2);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (4, 1, 3);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (4, 6, 16);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (4, 6, 17);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (4, 6, 18);

INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (5, 2, 4);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (5, 2, 5);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (5, 2, 6);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (5, 5, 13);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (5, 5, 14);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (5, 5, 15);

INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (6, 3, 7);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (6, 3, 8);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (6, 3, 20);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (6, 4, 10);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (6, 4, 11);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (6, 4, 12);



INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (7, 2, 4);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (7, 2, 5);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (7, 2, 9);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (7, 4, 10);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (7, 4, 11);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (7, 4, 12);

INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (8, 3, 7);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (8, 3, 8);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (8, 3, 20);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (8, 6, 16);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (8, 6, 17);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (8, 6, 18);

INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (9, 1, 1);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (9, 1, 2);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (9, 1, 3);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (9, 5, 13);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (9, 5, 14);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (9, 5, 19);


INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (10, 1, 1);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (10, 1, 2);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (10, 1, 3);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (10, 4, 10);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (10, 4, 7);
INSERT INTO "C22-702-24".players_on_field (match_id, team_id, player_id) VALUES (10, 4, 12);




INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (1, 30, 15);
INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (3, 50, 55);
INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (5, 12, 12);

INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (7, 42, 13);
INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (8, 52, 23);
INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (8, 82, 34);

INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (13, 47, 47);


INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (19, 13, 22);
INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (19, 23, 13);
INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (20, 33, 54);
INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (23, 44, 15);
INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (21, 55, 46);
INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (19, 66, 17);

INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (25, 13, 12);
INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (27, 23, 13);
INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (29, 33, 14);

INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (34, 13, 12);
INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (36, 83, 43);


INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (37, 42, 12);
INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (38, 52, 12);
INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (38, 62, 12);
INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (41, 82, 12);

INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (44, 71, 10);

INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (49, 13, 12);
INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (51, 43, 33);
INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (53, 53, 14);

INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (55, 21, 12);
INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (59, 52, 14);
INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (59, 53, 52);
INSERT INTO "C22-702-24".goals (player_on_field_id, minutes, seconds) VALUES (56, 84, 32);


INSERT INTO "C22-702-24".violations (player_on_field_id, minutes, seconds, type_of_violation) VALUES (2, 10, 1, 'Offside');
INSERT INTO "C22-702-24".violations (player_on_field_id, minutes, seconds, type_of_violation) VALUES (5, 20, 2, 'Offside');
INSERT INTO "C22-702-24".violations (player_on_field_id, minutes, seconds, type_of_violation) VALUES (8, 30, 3, 'Foul');
INSERT INTO "C22-702-24".violations (player_on_field_id, minutes, seconds, type_of_violation) VALUES (11, 40, 44, 'Yellow Card');
INSERT INTO "C22-702-24".violations (player_on_field_id, minutes, seconds, type_of_violation) VALUES (14, 50, 51, 'Red Card');
INSERT INTO "C22-702-24".violations (player_on_field_id, minutes, seconds, type_of_violation) VALUES (17, 50, 59, 'Diving');
INSERT INTO "C22-702-24".violations (player_on_field_id, minutes, seconds, type_of_violation) VALUES (17, 80, 18, 'Offside');
INSERT INTO "C22-702-24".violations (player_on_field_id, minutes, seconds, type_of_violation) VALUES (21, 2, 27, 'Foul');
INSERT INTO "C22-702-24".violations (player_on_field_id, minutes, seconds, type_of_violation) VALUES (27, 44, 33, 'Handball');
INSERT INTO "C22-702-24".violations (player_on_field_id, minutes, seconds, type_of_violation) VALUES (33, 11, 19, 'Offside');
INSERT INTO "C22-702-24".violations (player_on_field_id, minutes, seconds, type_of_violation) VALUES (35, 19, 19, 'Foul');
INSERT INTO "C22-702-24".violations (player_on_field_id, minutes, seconds, type_of_violation) VALUES (38, 57, 45, 'Handball');
INSERT INTO "C22-702-24".violations (player_on_field_id, minutes, seconds, type_of_violation) VALUES (41, 57, 45, 'Offside');
INSERT INTO "C22-702-24".violations (player_on_field_id, minutes, seconds, type_of_violation) VALUES (44, 87, 55, 'Yellow Card');
INSERT INTO "C22-702-24".violations (player_on_field_id, minutes, seconds, type_of_violation) VALUES (47, 47, 47, 'Red Card');
INSERT INTO "C22-702-24".violations (player_on_field_id, minutes, seconds, type_of_violation) VALUES (51, 47, 47, 'Foul');
INSERT INTO "C22-702-24".violations (player_on_field_id, minutes, seconds, type_of_violation) VALUES (53, 62, 47, 'Offside');
INSERT INTO "C22-702-24".violations (player_on_field_id, minutes, seconds, type_of_violation) VALUES (53, 57, 57, 'Red Card');
INSERT INTO "C22-702-24".violations (player_on_field_id, minutes, seconds, type_of_violation) VALUES (56, 37, 17, 'Foul');
INSERT INTO "C22-702-24".violations (player_on_field_id, minutes, seconds, type_of_violation) VALUES (58, 47, 37, 'Handball');
INSERT INTO "C22-702-24".violations (player_on_field_id, minutes, seconds, type_of_violation) VALUES (60, 77, 27, 'Yellow Card');







--TASKS
--task0
WITH tmp AS(
    SELECT pf.id , pf.player_id , 
    (SELECT COUNT(*) FROM "C22-702-24".goals g WHERE g.player_on_field_id=pf.id) as goals
    FROM "C22-702-24".players_on_field pf 
    GROUP BY pf.id
)
SELECT p.player_id , p.name , p.last_name , (SELECT SUM(goals) FROM tmp WHERE p.player_id=tmp.player_id) 
FROM "C22-702-24".players p 
GROUP BY p.player_id
ORDER BY p.player_id;

--task1
WITH tmp AS(
    SELECT pf1.match_id , 
    (SELECT COUNT(*) FROM "C22-702-24".violations v WHERE v.player_on_field_id IN (SELECT pf2.id FROM "C22-702-24".players_on_field pf2 WHERE pf2.match_id=pf1.match_id)) AS viol
    FROM "C22-702-24".players_on_field pf1
    GROUP BY pf1.match_id
)

SELECT AVG(viol) FROM tmp;

--task2
WITH 
tmp1 AS(
    SELECT s.match_id , s.first_goals+s.second_goals as res FROM "C22-702-24".schedule s
),
tmp2 AS(
    SELECT pf1.match_id , 
    (SELECT COUNT(*) 
    FROM "C22-702-24".violations v 
    WHERE v.player_on_field_id IN (SELECT pf2.id 
                                   FROM "C22-702-24".players_on_field pf2 
                                   WHERE pf2.match_id=pf1.match_id)
    ) AS res
    FROM "C22-702-24".players_on_field pf1
    GROUP BY pf1.match_id
)
SELECT 'most resultive match',* FROM tmp1 WHERE res=(SELECT MAX(res) FROM tmp1)
UNION ALL
SELECT 'most violation match',* FROM tmp2 WHERE res=(SELECT MAX(res) FROM tmp2) LIMIT 2;


--task3
BEGIN;
DELETE FROM "C22-702-24".schedule WHERE first_score IS NULL AND second_score IS NULL;
SELECT * FROM "C22-702-24".schedule;
ROLLBACK;


--task4
BEGIN;
UPDATE "C22-702-24".clubs SET long_club_name='Football club '||long_club_name;
ROLLBACK;


--task5
BEGIN;

ALTER TABLE "C22-702-24".schedule
ADD name_of_judge character varying;
ROLLBACK;

--task6

CREATE OR REPLACE FUNCTION check_points_filled()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.first_score = 1 AND NEW.second_score = 1 AND (NEW.first_goals IS NULL OR NEW.second_goals IS NULL) THEN
        RAISE EXCEPTION 'forbidden a draw result without points received';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER prevent_empty_points
BEFORE INSERT OR UPDATE ON "C22-702-24".schedule
FOR EACH ROW
EXECUTE FUNCTION check_points_filled();

INSERT INTO "C22-702-24".schedule 
(first_team, second_team, date_of_match, first_goals, first_after_match_penalty, second_goals, second_after_match_penalty, first_score, second_score, type_of_match) 
VALUES (10, 11, '2024-04-30', null , null, 0, null, 1, 1, 'group stage');

--???
