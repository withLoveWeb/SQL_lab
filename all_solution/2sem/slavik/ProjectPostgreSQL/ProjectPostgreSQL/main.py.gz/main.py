import sys
import datetime
import time
sys.path.append('tables')

from project_config import *
from dbconnection import *
from countries_table import *
from players_table import *


def smart_int(value):
    if isinstance(value, str):
        try:
            int_value = int(value)
            return int_value
        except ValueError:
            return None
    else:
        return None
def is_valid_date(date_str):
    try:
        datetime.datetime.strptime(date_str, '%Y-%m-%d')
        return True
    except ValueError:
        return False


class Main:

    config = ProjectConfig()
    connection = DbConnection(config)

    def __init__(self):
        DbTable.dbconn = self.connection
        return

    def db_init(self):
        cnt = CountriesTable()
        plr = PlayersTable()
        cnt.create()
        plr.create()

        return

    def db_insert_somethings(self):
        cnt = CountriesTable()
        plr = PlayersTable()
        cnt.insert_one(['UK', 'United Kingdom', 'Europe'])
        cnt.insert_one(['DE', 'Germany', 'Europe'])
        cnt.insert_one(['GE', 'Georgia', 'Asia'])
        cnt.insert_one(['CG', 'Congo', 'Africa'])
        cnt.insert_one(['PL', 'Poland', 'Europe'])
        cnt.insert_one(['TG', 'Togo', 'Africa'])
        cnt.insert_one(['RUS', 'Russia', 'Asia'])

        plr.insert_one(['Alexander', 'Smith', 'Johnson', '1990-01-01', 1])
        plr.insert_one(['Benjamin', 'Williams', 'Brown', '1991-02-02', 2])
        plr.insert_one(['Christopher', 'Jones', 'Davis', '1992-03-03', 3])
        plr.insert_one(['Daniel', 'Martinez', 'Wilson', '1993-04-04', 4])
        plr.insert_one(['Edward', 'Taylor', 'Anderson', '1994-05-05', 5])
        plr.insert_one(['Felix', 'Brown', 'Thompson', '1995-06-06', 6])
        plr.insert_one(['George', 'Wilson', 'Clark', '1996-07-07', 1])
        plr.insert_one(['Henry', 'Johnson', 'Lewis', '1997-08-08', 2])

    def db_drop(self):
        cnt = CountriesTable()
        plr = PlayersTable()
        cnt.drop()
        plr.drop()
        return

    def show_main_menu(self):
        menu = """Добро пожаловать! 
Основное меню (выберите цифру в соответствии с необходимым действием): 
    1 - просмотр стран;
    2 - сброс и инициализация таблиц;
    9 - выход."""
        print(menu)
        return

    def read_next_step(self):
        return input("=> ").strip()

    def after_main_menu(self, next_step):
        if next_step == "2":
            self.db_drop()
            self.db_init()
            self.db_insert_somethings()
            print("Таблицы созданы заново!")
            return "0"
        elif next_step != "1" and next_step != "9":
            print("Выбрано неверное число! Повторите ввод!")
            return "0"
        else:
            return next_step
            
    def show_countries(self):
        self.country_id = -1
        menu = """Просмотр списка стран!
id\t\tshort_name\t\tlong_name\t\tregion"""
        print(menu)
        lst = CountriesTable().all()
        count = 1
        for i in lst:
            print(str(count) + "\t\t" + str(i[0]) + "\t\t" + str(i[1]) + "\t\t" + str(i[2]))
            count+=1
        menu = """Дальнейшие операции: 
    0 - возврат в главное меню;
    3 - добавление новой страны;
    4 - удаление страны;
    5 - просмотр игроков страны;
    9 - выход."""
        print(menu)
        return

    def after_show_countries(self, next_step):
        while True:
            if next_step == "4":
                next_step = self.show_delete_country()
                return "1"
            elif next_step == "6":
                next_step = self.show_add_player()
            elif next_step == "7":
                next_step = self.show_delete_player()
                next_step = "5"
            elif next_step == "5":
                next_step = self.show_players_by_country()
            elif next_step != "0" and next_step != "9" and next_step != "3":
                print("Выбрано неверное число! Повторите ввод!")
                return "1"
            else:
                return next_step

    def show_add_country(self):
        regions = {"Asia" ,"Europe" ,"Africa" ,"Australia and Oceania" ,"North America" ,"South and Latin America"}
        # Не реализована проверка на максимальную длину строк. Нужно доделать самостоятельно!
        data = []
        data.append(input("Введите короткое название (1 - отмена): ").strip())
        if data[0] == "1":
            return
        while len(data[0].strip()) == 0:
            data[0] = input("Короткое название не может быть пустым! Введите короткое название заново (1 - отмена):").strip()
            if data[0] == "1":
                return
        data.append(input("Введите полное название (1 - отмена): ").strip())
        if data[1] == "1":
            return
        while len(data[1].strip()) == 0:
            data[1] = input("полное название не может быть пустым! Введите полное название заново (1 - отмена):").strip()
            if data[1] == "1":
                return
        data.append(input("Введите регион (1 - отмена):").strip())
        if data[2] == "1":
            return
        data[2]=str(data[2])
        while len(data[2].strip()) == 0:
            data[2] = input("Регион не может быть пустым! Введите регион заново (1 - отмена):").strip()
            if data[2] == "1":
                return
        while data[2].strip() not in regions:
            data[2] = input(f"Регион может быть только одним из следующих:\n{regions}\nВведите заново:").strip()
            if data[2] == "1":
                return
        countries_table=CountriesTable()
        if countries_table.select(data)!=None:
            print("Такая строка уже существует")
            return
        countries_table.insert_one(data)
        return

    def show_add_player(self):
        # Не реализована проверка на максимальную длину строк. Нужно доделать самостоятельно!
        data = []
        data.append(input("Введите имя (1 - отмена): ").strip())
        if data[0] == "1":
            return
        while len(data[0].strip()) == 0:
            data[0] = input("Имя не может быть пустым! Введите имя заново (1 - отмена):").strip()
            if data[0] == "1":
                return
        data.append(input("Введите фамилию (1 - отмена): ").strip())
        if data[1] == "1":
            return
        while len(data[1].strip()) == 0:
            data[1] = input("Фамилия не может быть пустым! Введите фамилию заново (1 - отмена):").strip()
            if data[1] == "1":
                return
        data.append(input("Введите отчество (1 - отмена):").strip())
        if data[2] == "1":
            return

        date = input("Введите дату рождения(пример 1999-03-28) (1 - отмена):").strip()
        if date == "1":
            return

        while not is_valid_date(date):
            print("Некорректная дата")
            date = input("Введите дату рождения(пример 1999-03-28) (1 - отмена):").strip()
        data.append(date)


        players_table = PlayersTable()
        data.append(self.country_id)
        if players_table.select(data)!=None:
            print("Строка уже существует")
            return
        players_table.insert_one(data)
        return


    def show_delete_player(self):
        num = input("Укажите номер строки, которую хотите удалить (0 - отмена):")
        while len(num.strip()) == 0 :
            num = input("Пустая строка. Повторите ввод! Укажите номер строки, в которой записана интересующая Вас страна (0 - отмена):")
        if num == "0":
            return "1"
        sm = smart_int(num)
        if not sm:
            return "1"
        p = (PlayersTable().find_by_position(sm))
        if p is None:
            print("Нет такой строки")
            return
        player = p[0]
        PlayersTable().delete_one(player)
        return

    def show_delete_country(self):
        num = input("Укажите номер строки, которую хотите удалить (0 - отмена):")
        while len(num.strip()) == 0 :
            num = input("Пустая строка. Повторите ввод! Укажите номер строки, в которой записана интересующая Вас страна (0 - отмена):")
        if num == "0":
            return "1"
        sm = smart_int(num)
        if not sm:
            return "1"
        c = (CountriesTable().find_by_position(sm))
        if c is None:
            print("Нет такой строки")
            return
        country = c[0]
        CountriesTable().delete_one(country)
        return


    def show_players_by_country(self):
        if self.country_id == -1:
            while True:
                num = input("Укажите номер строки, в которой записана интересующая Вас страна (0 - отмена):")
                while len(num.strip()) == 0 :
                    num = input("Пустая строка. Повторите ввод! Укажите номер строки, в которой записана интересующая Вас страна (0 - отмена):")
                if num == "0":
                    return "1"
                sm = smart_int(num)
                if not sm:
                    return "1"
                country = CountriesTable().find_by_position(sm)
                if country==None:
                    print("Введено число, неудовлетворяющее количеству стран!")
                else:
                    self.country_id = int(country[0])
                    self.country_obj = country
                    break
        print("Выбрана страна: " + self.country_obj[1] + " " + self.country_obj[2])
        print("Игроки:")
        lst = PlayersTable().all_by_country_id(self.country_id)
        count = 1
        for i in lst:
            print(f"{count}  {i[0]}  {i[1]}  {i[2]}  {i[3]}")
            # print(f"{count}  {i}")

            count+=1
        menu = """Дальнейшие операции:
    0 - возврат в главное меню;
    1 - возврат в просмотр стран;
    6 - добавление нового игрока;
    7 - удаление игрока;
    9 - выход."""
        print(menu)
        return self.read_next_step()

        return self.read_next_step()

    def main_cycle(self):
        current_menu = "0"
        next_step = None
        while(current_menu != "9"):
            if current_menu == "0":
                self.show_main_menu()
                next_step = self.read_next_step()
                current_menu = self.after_main_menu(next_step)
            elif current_menu == "1":
                self.show_countries()
                next_step = self.read_next_step()
                current_menu = self.after_show_countries(next_step)
            elif current_menu == "2":
                self.show_main_menu()
            elif current_menu == "3":
                self.show_add_country()
                current_menu = "1"
        print("До свидания!")    
        return

    def test(self):
        DbTable.dbconn.test()

m = Main()
# Откоментируйте эту строку и закоментируйте следующую для теста
# соединения с БД
# m.test()
m.main_cycle()
    
