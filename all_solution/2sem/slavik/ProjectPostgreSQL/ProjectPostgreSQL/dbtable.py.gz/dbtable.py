# Базовые действия с таблицами

from dbconnection import *

class DbTable:
    dbconn = None

    def __init__(self):
        return

    def table_name(self):
        return self.dbconn.prefix + "table"

    def columns(self):
        return {"test": ["integer", "PRIMARY KEY"]}

    def column_names(self):
        return sorted(self.columns().keys(), key = lambda x: x)

    def primary_key(self):
        return ['id']

    def column_names_without_id(self):
        res = sorted(self.columns().keys(), key = lambda x: x)
        if 'id' in res:
            res.remove('id')
        return res

    def table_constraints(self):
        return []

    def create(self):
        sql = "CREATE TABLE " + self.table_name() + "("
        arr = [k + " " + " ".join(v) for k, v in sorted(self.columns().items(), key = lambda x: x[0])]

        sql += ", ".join(arr + self.table_constraints())
        sql += ")"
        cur = self.dbconn.conn.cursor()
        # print(sql)
        cur.execute(sql)
        self.dbconn.conn.commit()
        return

    def drop(self):
        sql = "DROP TABLE IF EXISTS " + self.table_name() + " CASCADE"
        cur = self.dbconn.conn.cursor()
        cur.execute(sql)
        self.dbconn.conn.commit()
        return

    def insert_one(self, vals):
        for i in range(0, len(vals)):
            # if isinstance(vals[i], str):
            #     pass
            #     # vals[i] = "'" + vals[i] + "'"
            # else:
            vals[i] = str(vals[i])
        
        cur = self.dbconn.conn.cursor()

        cur.execute("BEGIN")
        sql = "INSERT INTO %s(%s) VALUES(%s)"
        column_names = self.column_names_without_id()
        placeholder = ", ".join(["%s"] * len(column_names))
        query = sql % (self.table_name(), ", ".join(column_names), placeholder)
        cur.execute(query, vals)
        cur.execute("COMMIT")




    def first(self):
        cur = self.dbconn.conn.cursor()
        cur.execute(f"SELECT * FROM {self.table_name()} ORDER BY {self.primary_key()[0]}")
        return cur.fetchone()
    

    def last(self):
        cur = self.dbconn.conn.cursor()
        cur.execute(f"SELECT * FROM {self.table_name()} ORDER BY {self.primary_key()[0]} DESC")
        return cur.fetchone()

    def all(self):
        cur = self.dbconn.conn.cursor()
        cur.execute(f"SELECT * FROM {self.table_name()} ORDER BY {self.primary_key()[0]}")
        return cur.fetchall()
        
