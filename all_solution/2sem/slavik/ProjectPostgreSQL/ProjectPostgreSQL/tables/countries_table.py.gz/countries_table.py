# Таблица персоны и особые действия с ней

from dbtable import *

class CountriesTable(DbTable):
    def table_name(self):
        return f'"{self.dbconn.prefix}".countries'


    def child_table_name(self):
        return f'"{self.dbconn.prefix}".players'

    def table_constraints(self):
        return ["UNIQUE(short_country_name, long_country_name)"]
    def primary_key(self):
        return [f"country_id"]

    def columns(self):
        return {"country_id": ["serial", "PRIMARY KEY"],
                "short_country_name": ["varchar", "NOT NULL"],
                "long_country_name": ["varchar", "NOT NULL"],
                "region_name": ["varchar","NOT NULL"]}

    def column_names_without_id(self):
        return ["short_country_name","long_country_name","region_name"]

    def find_by_position(self, num):
        sql = "SELECT * FROM " +self.table_name()+  " ORDER BY " +self.primary_key()[0]+ " LIMIT 1 OFFSET %s"
        cur = self.dbconn.conn.cursor()
        cur.execute(sql,(str(num-1),))
        return cur.fetchone()
    def select(self,data):
        short_country_name, long_country_name = data[0],data[1]

        cur = self.dbconn.conn.cursor()
        sql = "SELECT * FROM "+self.table_name()+" WHERE short_country_name=%s AND long_country_name=%s"
        cur.execute(sql,(short_country_name,long_country_name))
        return cur.fetchone()

    def delete_one(self,id_):

        cur = self.dbconn.conn.cursor()
        cur.execute("BEGIN")

        sql = "DELETE FROM " +self.child_table_name()+ " WHERE country_id=%s"
        cur.execute(sql, (id_,))
        cur.execute("COMMIT")
        cur.execute("BEGIN")

        sql = "DELETE FROM " +self.table_name()+ " WHERE country_id=%s RETURNING *"
        cur.execute(sql, (id_,))
        ans = cur.fetchone()
        cur.execute("COMMIT")

        return ans
        # return

    def all(self):
        cur = self.dbconn.conn.cursor()
        cur.execute(f"SELECT short_country_name,long_country_name,region_name FROM {self.table_name()} ORDER BY {self.primary_key()[0]}")
        return cur.fetchall()