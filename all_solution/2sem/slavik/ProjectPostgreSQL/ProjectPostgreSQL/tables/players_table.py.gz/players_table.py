# Таблица Телефоны и особые действия с ней.

from dbtable import *

class PlayersTable(DbTable):
    def table_name(self):
        return f'"{self.dbconn.prefix}".players'
        


    def primary_key(self):
        return [f"player_id"]

    def columns(self):
        return {"player_id": ["serial", "PRIMARY KEY"],
                "name": ["varchar", "NOT NULL"],
                "last_name": ["varchar", "NOT NULL"],
                "second_name": ["varchar"],
                "birthday": ["date"],
                "country_id": ["integer"]
                }
    def column_names_without_id(self):
        return ["name","last_name","second_name","birthday","country_id"]


    def table_constraints(self):
        return ["UNIQUE(name, last_name, second_name, birthday)"]

    def find_by_position(self, num):
        sql = "SELECT player_id FROM " +self.table_name()+  " ORDER BY " +self.primary_key()[0]+ " LIMIT 1 OFFSET %s"
        cur = self.dbconn.conn.cursor()
        cur.execute(sql,(str(num-1),))
        return cur.fetchone()

    def all_by_country_id(self, pid):
        # params = [self.table_name(),str(pid),self.primary_key()[0]]
        # sql = "SELECT * FROM %s WHERE country_id = %s ORDER BY %s" 
        cur = self.dbconn.conn.cursor()
        sql = "SELECT name,last_name,second_name,birthday FROM " + self.table_name() + " WHERE country_id = %s ORDER BY " + self.primary_key()[0]
        cur.execute(sql , (str(pid),))
        return cur.fetchall()           

    def select(self,data):
        cur = self.dbconn.conn.cursor()
        params = [data[0],data[1],data[2],data[3]]
        sql = "SELECT * FROM "+self.table_name()+ " WHERE name=%s AND last_name=%s AND second_name=%s AND birthday=%s "
        cur.execute(sql,params)
        return cur.fetchone()

    def delete_one(self,id_):
        cur = self.dbconn.conn.cursor()
        cur.execute("BEGIN")
        sql = "DELETE FROM "+self.table_name()+ " WHERE player_id=%s RETURNING *"
        cur.execute(sql,(id_,))
        ans = cur.fetchone()
        cur.execute("COMMIT")
        return ans