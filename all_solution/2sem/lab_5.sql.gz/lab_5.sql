-- 0
CREATE OR REPLACE FUNCTION check_goals()
RETURNS TRIGGER AS $$
BEGIN
    IF OLD.first_goals = 0 AND OLD.second_goals = 0  AND ((OLD.first_goals != NEW.first_goals) OR (OLD.second_goals != NEW.second_goals)) THEN
        -- RAISE NOTICE '% %',OLD.first_goals,NEW.first_goals;
        -- RAISE NOTICE '% %',OLD.second_goals,NEW.second_goals;
        RAISE EXCEPTION 'forbidden adding goals if result is 0 0';


    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE TRIGGER check_goals
BEFORE UPDATE ON "C22-702-24".schedule
FOR EACH ROW
EXECUTE FUNCTION check_goals();

-- DROP TRIGGER check_goals;

-- UPDATE "C22-702-24".schedule SET first_goals=0 , second_goals=0  WHERE match_id = 11;
-- !!
UPDATE "C22-702-24".schedule SET first_goals=first_goals+1 WHERE first_goals=0 AND second_goals=0  ;    



UPDATE "C22-702-24".schedule SET type_of_match='1/8' WHERE first_goals=0 AND second_goals=0  ;
UPDATE "C22-702-24".schedule SET type_of_match='group stage' WHERE first_goals=0 AND second_goals=0  ;


-- 1
CREATE OR REPLACE PROCEDURE player_useful(player_id_ integer)
AS $$
DECLARE
    player_goals integer;
    player_violations integer;
    player_matches integer;
    answer float;
BEGIN
    WITH tmp AS(
        SELECT pf.id , pf.player_id , 
        (SELECT COUNT(*) FROM "C22-702-24".goals g WHERE g.player_on_field_id=pf.id) as goals
        FROM "C22-702-24".players_on_field pf 
        GROUP BY pf.id
    )
    SELECT (SELECT SUM(goals) FROM tmp WHERE p.player_id=tmp.player_id) INTO player_goals
    FROM "C22-702-24".players p 
    WHERE p.player_id=player_id_;

    WITH tmp AS(
        SELECT pf.id , pf.player_id , 
        (SELECT COUNT(*) FROM "C22-702-24".violations v WHERE v.player_on_field_id=pf.id) as violations
        FROM "C22-702-24".players_on_field pf 
        GROUP BY pf.id
    )
    SELECT (SELECT SUM(violations) FROM tmp WHERE p.player_id=tmp.player_id) INTO player_violations
    FROM "C22-702-24".players p 
    WHERE p.player_id=player_id_;

    SELECT COUNT(*) INTO player_matches FROM "C22-702-24".players_on_field WHERE player_id=player_id_;

    answer = (player_goals::float-player_violations::float)/player_matches::float;

    RAISE NOTICE 'player_goals = % ',player_goals;
    RAISE NOTICE 'player_violations = % ',player_violations;
    RAISE NOTICE 'player_matches = % ',player_matches;

    RAISE NOTICE 'player_useful = % ',answer;



END;
$$ LANGUAGE plpgsql;




CALL player_useful(1);


--2

CREATE OR REPLACE FUNCTION SF(BIGINT[], INTEGER) RETURNS BIGINT[] AS $$
DECLARE
	sres bigint;
BEGIN
	IF $2 IS NULL THEN
		RETURN $1;
	END IF;
	RAISE INFO '% % ' , $1 , $2;
	SELECT (first_goals+second_goals) INTO sres FROM "C22-702-24".schedule
		WHERE match_id = $2;
	IF sres IS NULL THEN
		RETURN $1;
	END IF;
	$1[1] = $1[1] + sres;
	$1[2] = $1[2] + 1;
	RETURN $1;
END;
$$ language plpgsql;

CREATE OR REPLACE FUNCTION FF(BIGINT[]) RETURNS NUMERIC AS $$
BEGIN
	IF $1[2] = 0 THEN
		RAISE WARNING 'На 0 делить нельзя';
		RETURN NULL;
	ELSE
		RETURN $1[1]/$1[2]::numeric;
	END IF;
END;
$$ language plpgsql;

CREATE OR REPLACE AGGREGATE AF(INTEGER)(
	SFUNC = SF,
	FINALFUNC = FF,
	STYPE = BIGINT[],
	INITCOND = '{0,0}'
);

SELECT AF(match_id),AVG(first_goals)+AVG(second_goals) FROM "C22-702-24".schedule ;

--3


DROP VIEW IF EXISTS test_view;
CREATE OR REPLACE VIEW test_view (violation_id,name, last_name, second_name, type_of_violation) AS
    SELECT 
        v.violation_id,
        (SELECT p.name FROM "C22-702-24".players p WHERE p.player_id = pf.player_id),
        (SELECT p.last_name FROM "C22-702-24".players p WHERE p.player_id = pf.player_id),
        (SELECT p.second_name FROM "C22-702-24".players p WHERE p.player_id = pf.player_id),
        v.type_of_violation
    FROM "C22-702-24".violations v JOIN "C22-702-24".players_on_field pf ON v.player_on_field_id=pf.id;



CREATE OR REPLACE FUNCTION update_test_view() RETURNS TRIGGER AS $$
BEGIN
    UPDATE "C22-702-24".violations
    SET type_of_violation = NEW.type_of_violation
    WHERE violation_id = NEW.violation_id;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_test_view_trigger
INSTEAD OF UPDATE ON test_view
FOR EACH ROW
EXECUTE FUNCTION update_test_view();

SELECT * FROM test_view;

UPDATE test_view SET type_of_violation = 'Red Card' WHERE violation_id=21;

UPDATE test_view SET type_of_violation = 'Yellow Card' WHERE violation_id=21;


--4

--init queue 
CREATE OR REPLACE PROCEDURE init_q(table_name varchar)
AS $$
DECLARE
    create_table_query TEXT;
BEGIN
    EXECUTE 'DROP TABLE IF EXISTS ' || table_name;
    create_table_query := 'CREATE TABLE ' || table_name || ' (id SERIAL PRIMARY KEY, data varchar(64))';
    EXECUTE create_table_query;
    
    EXECUTE 'TRUNCATE TABLE ' || table_name;
END;
$$ LANGUAGE plpgsql;


-- enqueue_q
CREATE OR REPLACE PROCEDURE enqueue_q(queue_name varchar, new_data varchar(64))
AS $$
BEGIN
    EXECUTE 'INSERT INTO ' || queue_name || '(data) VALUES ($1)' USING new_data;
END;
$$ LANGUAGE plpgsql;


-- dequeue_q
CREATE OR REPLACE PROCEDURE dequeue_q(queue_name varchar)
AS $$
BEGIN
    EXECUTE 'DELETE FROM ' || queue_name || ' WHERE id = (SELECT MIN(id) FROM ' || queue_name || ')';
END;
$$ LANGUAGE plpgsql;

-- empty stack
CREATE OR REPLACE PROCEDURE empty_q(queue_name VARCHAR)
AS $$
BEGIN
    EXECUTE 'DELETE FROM ' || queue_name;
END;
$$ LANGUAGE plpgsql;

-- top q
CREATE OR REPLACE FUNCTION top_q(queue_name VARCHAR)
RETURNS VARCHAR(64) AS $$
DECLARE
    top_element VARCHAR(64);
BEGIN
    EXECUTE 'SELECT data FROM ' || queue_name || ' WHERE id = (SELECT MIN(id) FROM '|| queue_name ||')' INTO top_element;
    RETURN top_element;
END;
$$ LANGUAGE plpgsql;

-- tail q
CREATE OR REPLACE FUNCTION tail_q(queue_name VARCHAR)
RETURNS VARCHAR(64) AS $$
DECLARE
    top_element VARCHAR(64);
BEGIN
    EXECUTE 'SELECT data FROM ' || queue_name || ' WHERE id = (SELECT MAX(id) FROM '|| queue_name ||')' INTO top_element;
    RETURN top_element;
END;
$$ LANGUAGE plpgsql;



CALL init_q('test');
CALL enqueue_q('test', 'd1');
CALL enqueue_q('test', 'd22');
CALL enqueue_q('test', 'd333');

SELECT top_q('test');
SELECT tail_q('test');

CALL dequeue_q('test');

SELECT top_q('test');
SELECT tail_q('test');

CALL enqueue_q('test', 'd444');

SELECT top_q('test');
SELECT tail_q('test');


CALL empty_q('test');

SELECT tail_q('test');