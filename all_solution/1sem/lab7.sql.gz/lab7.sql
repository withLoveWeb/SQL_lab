DROP TABLE IF EXISTS people_log;
DROP TABLE IF EXISTS people;

CREATE SEQUENCE people_log_sequence
    START WITH 1
    INCREMENT BY 1;

CREATE TABLE people (
    id INT PRIMARY KEY,
    first_name varchar(50),
    last_name varchar(50),
    birthday DATE,
    amount numeric(10, 2)
);

CREATE TABLE people_log (
    id INT PRIMARY KEY,
    person_id INT,
    operation_date TIMESTAMP,
    sum numeric(10, 2),
    FOREIGN KEY (person_id) REFERENCES people(id)
);


INSERT INTO people (id, first_name, last_name, birthday, amount) VALUES (1, 'John', 'Doe', '1990-05-15', 1000.00);
INSERT INTO people (id, first_name, last_name, birthday, amount) VALUES (2, 'Jane', 'Smith', '1985-12-02', 2500.50);
INSERT INTO people (id, first_name, last_name, birthday, amount) VALUES (3, 'Michael', 'Johnson', '1992-08-20', 500.75);
INSERT INTO people (id, first_name, last_name, birthday, amount) VALUES (4, 'Emily', 'Brown', '1998-03-10', 1500.25);
INSERT INTO people (id, first_name, last_name, birthday, amount) VALUES (5, 'David', 'Wilson', '1987-11-30', 3000.00);
INSERT INTO people (id, first_name, last_name, birthday, amount) VALUES (6, 'Sarah', 'Davis', '1995-06-25', 200.50);
INSERT INTO people (id, first_name, last_name, birthday, amount) VALUES (7, 'Christopher', 'Anderson', '1991-09-12', 750.00);
INSERT INTO people (id, first_name, last_name, birthday, amount) VALUES (8, 'Olivia', 'Taylor', '1997-04-05', 1200.75);
INSERT INTO people (id, first_name, last_name, birthday, amount) VALUES (9, 'Daniel', 'Miller', '1989-07-18', 1800.25);
INSERT INTO people (id, first_name, last_name, birthday, amount) VALUES (10, 'Ava', 'Clark', '1994-02-08', 900.50);

INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 1, '2023-11-10 09:30:00', 100.00);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 2, '2023-11-10 14:45:00', -50.25);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 3, '2023-11-11 11:20:00', 200.50);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 4, '2023-11-11 15:10:00', -75.75);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 5, '2023-11-11 18:00:00', 150.25);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 6, '2023-11-11 09:00:00', -20.50);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 7, '2023-11-11 13:30:00', 50.00);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 8, '2023-11-11 16:45:00', -100.75);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 9, '2023-11-11 10:15:00', 80.25);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 10,'2023-11-11 14:00:00', -30.50);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 1, '2023-08-11 10:30:00', 50.00);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 2, '2023-08-11 12:45:00', -100.50);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 3, '2023-08-11 15:20:00', 25.75);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 4, '2023-08-11 18:10:00', -75.25);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 5, '2023-08-11 20:35:00', 200.00);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 6, '2023-08-11 09:15:00', -10.50);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 7, '2023-08-11 11:40:00', 100.00);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 8, '2023-08-11 14:25:00', -50.75);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 9, '2023-08-11 17:05:00', 75.25);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 10, '2023-08-11 19:50:00', -150.50);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 1, '2023-04-10 10:30:00', 25.00);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 2, '2023-04-10 12:45:00', -50.50);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 3, '2023-04-10 15:20:00', 10.75);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 4, '2023-04-10 18:10:00', -25.25);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 5, '2023-04-10 20:35:00', 50.00);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 6, '2023-04-10 09:15:00', -5.50);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 7, '2023-04-10 11:40:00', 50.00);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 8, '2023-04-10 14:25:00', -25.75);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 9, '2023-04-10 17:05:00', 37.25);
INSERT INTO people_log (id, person_id, operation_date, sum) VALUES (nextval('people_log_sequence'), 10, '2023-04-10 19:50:00', -75.50);



CREATE OR REPLACE PROCEDURE statement_of_acount(start_date TIMESTAMP, end_date TIMESTAMP) AS 
$$
    DECLARE
        pos_cursor CURSOR FOR
            SELECT operation_date, sum
            FROM people_log
            WHERE operation_date > start_date AND operation_date < end_date
            AND sum > 0;
            
        neg_cursor CURSOR FOR
            SELECT operation_date, sum
            FROM people_log
            WHERE operation_date > start_date AND operation_date < end_date
            AND sum < 0;
            
        amount INT;
        pos_sum numeric(10, 2);
        neg_sum numeric(10, 2);

        pos_row people_log%ROWTYPE;
        neg_row people_log%ROWTYPE;
    BEGIN
        amount:=0;
        pos_sum:=0;
        neg_sum:=0;

        FOR pos_row IN pos_cursor LOOP
            pos_sum := pos_sum + pos_row.sum;
            amount := amount + 1;
        END LOOP;

        FOR neg_row IN neg_cursor LOOP
            neg_sum := neg_sum + neg_row.sum;
            amount := amount + 1;
        END LOOP;

        RAISE NOTICE 'sum of positive opertions = %',pos_sum;
        RAISE NOTICE 'sum of negative opertions = %',neg_sum;
        RAISE NOTICE 'total amount of operations = %',amount;
    END;
$$ LANGUAGE plpgsql;

CALL statement_of_acount('2023-07-01 10:00:00', '2023-12-06 17:30:00');



CREATE OR REPLACE PROCEDURE account_operation(p_id INT , operation_sum numeric(10,2)) AS
$$
    DECLARE
        p_row people%ROWTYPE;
        p_log_row people_log%ROWTYPE;
    BEGIN
        SELECT id, first_name, last_name, birthday, amount INTO p_row FROM people WHERE id = p_id;
        RAISE NOTICE 'before opperation % % % % %',p_row.id,p_row.first_name,p_row.last_name,p_row.birthday,p_row.amount;

        UPDATE people SET amount = amount + operation_sum WHERE id = p_id 
        RETURNING id, first_name, last_name, birthday, amount INTO p_row;
        RAISE NOTICE 'after operation % % % % %',p_row.id,p_row.first_name,p_row.last_name,p_row.birthday,p_row.amount;

        INSERT INTO people_log(id, person_id, operation_date, sum) VALUES(nextval('people_log_sequence'), p_id , CURRENT_TIMESTAMP , operation_sum) 
        RETURNING id, person_id, operation_date, sum INTO p_log_row;
        RAISE NOTICE '% % % %',p_log_row.id,p_log_row.person_id,p_log_row.operation_date,p_log_row.sum;
    END;
$$ LANGUAGE plpgsql;

CALL account_operation(4,20);
CALL account_operation(10,-25);