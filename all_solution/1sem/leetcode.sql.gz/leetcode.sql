-- Create table Employee (id int, name varchar(255), salary int, departmentId int);
-- Create table Department (id int, name varchar(255));
-- insert into Employee (id, name, salary, departmentId) values ('1', 'Joe', '85000', '1');
-- insert into Employee (id, name, salary, departmentId) values ('2', 'Henry', '80000', '2');
-- insert into Employee (id, name, salary, departmentId) values ('3', 'Sam', '60000', '2');
-- insert into Employee (id, name, salary, departmentId) values ('4', 'Max', '90000', '1');
-- insert into Employee (id, name, salary, departmentId) values ('5', 'Janet', '69000', '1');
-- insert into Employee (id, name, salary, departmentId) values ('6', 'Randy', '85000', '1');
-- insert into Employee (id, name, salary, departmentId) values ('7', 'Will', '70000', '1');
-- insert into Department (id, name) values ('1', 'IT');
-- insert into Department (id, name) values ('2', 'Sales');



-- SELECT dep.name , emp1.name , emp1.salary FROM department dep JOIN employee emp1 ON dep.id = emp1.departmentId
--  WHERE salary >= (
--     SELECT CASE 
--     WHEN (SELECT COUNT(DISTINCT salary) FROM employee WHERE departmentId = dep.id) >=3 
--     THEN (SELECT DISTINCT emp2.salary FROM employee emp2 WHERE emp2.departmentId = dep.id ORDER BY emp2.salary DESC LIMIT 1 OFFSET 2)
--     ELSE 0
--     END
--  );


-- WITH tmp AS(
--     SELECT DISTINCT emp2.salary,emp2.departmentId FROM employee emp2 GROUP BY emp2.departmentId ORDER BY emp2.salary DESC LIMIT 1 OFFSET 2; 
-- )
-- SELECT * FROM tmp;

-- SELECT DISTINCT emp2.salary FROM employee emp2 ORDER BY emp2.salary DESC LIMIT 1 OFFSET 2; 


-- SELECT CASE 
--     WHEN (SELECT COUNT(DISTINCT salary) FROM employee WHERE departmentId = 2 ) >=3 
--     THEN (SELECT DISTINCT emp2.salary FROM employee emp2 WHERE emp2.departmentId = 2 ORDER BY emp2.salary DESC LIMIT 1 OFFSET 2)
--     ELSE 0
--     END
-- ;

DROP TABLE Trips;
DROP TABLE Users;
Create table If Not Exists Trips (id int, client_id int, driver_id int, city_id int, status status_, request_at varchar(50));
Create table If Not Exists Users (users_id int, banned varchar(50), role role_);
insert into Trips (id, client_id, driver_id, city_id, status, request_at) values ('1', '1', '10', '1', 'completed', '2013-10-01');
insert into Trips (id, client_id, driver_id, city_id, status, request_at) values ('2', '2', '11', '1', 'cancelled_by_driver', '2013-10-01');
insert into Trips (id, client_id, driver_id, city_id, status, request_at) values ('3', '3', '12', '6', 'completed', '2013-10-01');
insert into Trips (id, client_id, driver_id, city_id, status, request_at) values ('4', '4', '13', '6', 'cancelled_by_client', '2013-10-01');
insert into Trips (id, client_id, driver_id, city_id, status, request_at) values ('5', '1', '10', '1', 'completed', '2013-10-02');
insert into Trips (id, client_id, driver_id, city_id, status, request_at) values ('6', '2', '11', '6', 'completed', '2013-10-02');
insert into Trips (id, client_id, driver_id, city_id, status, request_at) values ('7', '3', '12', '6', 'completed', '2013-10-02');
insert into Trips (id, client_id, driver_id, city_id, status, request_at) values ('8', '2', '12', '12', 'completed', '2013-10-03');
insert into Trips (id, client_id, driver_id, city_id, status, request_at) values ('9', '3', '10', '12', 'completed', '2013-10-03');
insert into Trips (id, client_id, driver_id, city_id, status, request_at) values ('10', '4', '13', '12', 'cancelled_by_driver', '2013-10-03');
insert into Users (users_id, banned, role) values ('1', 'No', 'client');
insert into Users (users_id, banned, role) values ('2', 'Yes', 'client');
insert into Users (users_id, banned, role) values ('3', 'No', 'client');
insert into Users (users_id, banned, role) values ('4', 'No', 'client');
insert into Users (users_id, banned, role) values ('10', 'No', 'driver');
insert into Users (users_id, banned, role) values ('11', 'No', 'driver');
insert into Users (users_id, banned, role) values ('12', 'No', 'driver');
insert into Users (users_id, banned, role) values ('13', 'No', 'driver');



INSERT INTO Trips (id, client_id, driver_id, city_id, status, request_at) values ('1', '1', '10', '1', 'completed', '2013-10-01');
insert into Users (users_id, banned, role) values ('1', 'Yes', 'client');
insert into Users (users_id, banned, role) values ('10', 'No', 'driver');






WITH tmp AS(
    SELECT t1.request_at AS day  , 
    ROUND(
    (SELECT COUNT(t2.status) FROM Trips t2 WHERE t2.status!='completed' AND
    (SELECT banned FROM Users WHERE users_id = t2.client_id)!='Yes' AND
    (SELECT banned FROM Users WHERE users_id = t2.driver_id)!='Yes' AND
    t2.request_at = t1.request_at
    ),2) AS cancelled
    ,
    ROUND(
    (SELECT COUNT(t2.status) FROM Trips t2 WHERE
    (SELECT banned FROM Users WHERE users_id = t2.client_id)!='Yes' AND
    (SELECT banned FROM Users WHERE users_id = t2.driver_id)!='Yes' AND
    t2.request_at = t1.request_at
    ),2) AS all
    FROM Trips AS t1 
    WHERE t1.request_at>='2013-10-01' AND 
    t1.request_at<='2013-10-03' AND 
    (SELECT COUNT(t2.status) FROM Trips t2 WHERE
    (SELECT banned FROM Users WHERE users_id = t2.client_id)!='Yes' AND
    (SELECT banned FROM Users WHERE users_id = t2.driver_id)!='Yes' AND
    t2.request_at = t1.request_at
    ) > 0
    GROUP BY request_at
)
-- SELECT * FROM tmp;
SELECT day , ROUND(tmp.cancelled/tmp.all,2) AS "Cancellation Rate"
FROM tmp ;