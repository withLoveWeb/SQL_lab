--1a
WITH RECURSIVE tmp AS(SELECT id , last_name , first_name , manager_id FROM bd6_employees WHERE id = 1
UNION    
SELECT b.id , b.last_name , b.first_name , b.manager_id FROM bd6_employees b JOIN tmp ON b.manager_id = tmp.id)
SELECT * FROM tmp;
--1b
CREATE OR REPLACE PROCEDURE recursive_employee() AS
$$
        DECLARE 
                emp_row record;
        BEGIN
                FOR emp_row IN
                WITH RECURSIVE tmp AS(SELECT id , last_name , first_name , manager_id FROM bd6_employees WHERE id = 1
                UNION    
                SELECT b.id , b.last_name , b.first_name , b.manager_id FROM bd6_employees b JOIN tmp ON b.manager_id = tmp.id)
                SELECT * FROM tmp
                LOOP
                    raise info 'Last name: % First Name: % My id = % Manager_id = %',
                            emp_row.last_name,
                            emp_row.first_name,
                            emp_row.id,
                            emp_row.manager_id;
                END LOOP;
        END
$$ language plpgsql;
CALL recursive_employee();


--2

CREATE OR REPLACE PROCEDURE modify_salary() AS
$$
    DECLARE
        new_salary numeric(8,2) := 0;
        firstt boolean := 1;
        leftover numeric(8, 2) := 0;
        em_row record;
    BEGIN
        FOR em_row IN
            SELECT first_name, last_name, salary_in_euro FROM bd6_employees
            ORDER BY salary_in_euro
            LOOP
                IF firstt THEN
                    new_salary := TRUNC(em_row.salary_in_euro, -2);
                    leftover := em_row.salary_in_euro - new_salary;
                    firstt := 0;
                ELSE
                    new_salary := TRUNC(em_row.salary_in_euro + leftover, -2);
                    leftover := em_row.salary_in_euro - new_salary;
                END IF;
                raise info 'Last Name: % First Name: %, Old salary: % , Modified salary: %',
                em_row.last_name,
                em_row.first_name,
                em_row.salary_in_euro,
                new_salary;
            END LOOP;
    END
$$ LANGUAGE plpgsql;
CALL modify_salary();


--3

CREATE OR REPLACE PROCEDURE change_salary() AS
$$
    BEGIN
        CREATE SEQUENCE high_seq
            START WITH 1
            INCREMENT BY 1;
        CREATE SEQUENCE low_seq
            START WITH 1
            INCREMENT BY 1; 
        CREATE TEMPORARY TABLE tmp_high AS
           SELECT nextval('high_seq') as num  ,id , salary_in_euro FROM bd6_employees ORDER BY salary_in_euro DESC LIMIT 10;
        
        CREATE TEMPORARY TABLE tmp_low AS
            SELECT nextval('low_seq') as num , id , salary_in_euro FROM bd6_employees ORDER BY salary_in_euro LIMIT 10;
        
        FOR i in 1..10 LOOP
            UPDATE bd6_employees SET salary_in_euro = salary_in_euro + (SELECT salary_in_euro FROM tmp_low WHERE num = i) 
            WHERE id = (SELECT id FROM tmp_high WHERE num = i);
            -- RETURNING *;
        END LOOP;

        -- DELETE FROM bd6_employees WHERE id IN (SELECT id FROM tmp_low);
        -- RETURNING *;
        
        DROP TABLE tmp_high;
        DROP TABLE tmp_low;
        DROP SEQUENCE high_seq;
        DROP SEQUENCE low_seq;
    END
        

$$ LANGUAGE plpgsql;

call change_salary();


--4
CREATE TABLE spiral_table(
    num1 int,
    num2 int,
    num3 int,
    num4 int,
    num5 int
);
CREATE OR REPLACE PROCEDURE spiral() AS
$$
    BEGIN
        FOR i IN 0..499 LOOP
            INSERT INTO spiral_table VALUES(
            i*10+1 , i*10+2 , i*10+3 , i*10+4 , i*10+5
            );
            INSERT INTO spiral_table VALUES(
            (i+1)*10 , (i+1)*10-1 , (i+1)*10-2 , (i+1)*10-3 , (i+1)*10-4
            );
        END LOOP;
    END
$$ LANGUAGE plpgsql;
call spiral();
SELECT * FROM spiral_table;